#include<stdio.h>
int linearsearch(int a[10],int element,int i,int n)
{
    int index = 0;
    if(i >= n)
    {
        return -1;
    }
    else if(a[i] == element)
    {
        index = i + 1;
    }
    else
    {
        return linearsearch(a,element,i+1,n);
    }
    return index;
}
int main()
{
    int index,element,n=10,i=0;
    int a[10] =  {12,61,33,92,36,3,29,98,54,60};
    printf("key element:");
    scanf("%d",&element);
    index = linearsearch(a,element,i,n);
    if(index != -1)
    {
         printf("element is found at %d index",index - 1);
    }
    else
    {
         printf("element is not found");
    }
    return 0;
}
